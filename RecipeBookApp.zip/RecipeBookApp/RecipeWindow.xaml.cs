﻿using System.Windows;
using RecipeBookApp;
using RecipeBookWPF.Models;

namespace RecipeBookWPF
{
    public partial class RecipeWindow : Window
    {
        private readonly Recipe _recipe;

        public RecipeWindow(Recipe recipe)
        {
            InitializeComponent();
            _recipe = recipe;
            RecipeNameTextBox.Text = recipe.Name; // Set the initial recipe name
        }

        // Remove this method, it's not needed
        // private void InitializeComponent()
        // {
        //     throw new NotImplementedException();
        // }

        private void AddIngredientButton_Click(object sender, RoutedEventArgs e)
        {
            var ingredientWindow = new IngredientWindow();
            if (ingredientWindow.ShowDialog() == true)
            {
                _recipe.AddIngredient(ingredientWindow.Ingredient);
                UpdateIngredientList();
            }
        }

        private void AddStepButton_Click(object sender, RoutedEventArgs e)
        {
            var step = Microsoft.VisualBasic.Interaction.InputBox("Enter step:");
            if (!string.IsNullOrWhiteSpace(step))
            {
                _recipe.AddStep(step);
                UpdateStepList();
            }
        }

        private void SaveRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            _recipe.Name = RecipeNameTextBox.Text; // Get the text from the TextBox
            DialogResult = true;
        }

        private void UpdateIngredientList()
        {
            IngredientListBox.ItemsSource = null;
            IngredientListBox.ItemsSource = _recipe.Ingredients;
        }

        private void UpdateStepList()
        {
            StepListBox.ItemsSource = null;
            StepListBox.ItemsSource = _recipe.Steps;
        }
    }
}
