﻿using RecipeBookWPF.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RecipeBookApp
{
    /// <summary>
    /// Interaction logic for DisplayRecipeWindow.xaml
    /// </summary>
    public partial class DisplayRecipeWindow : Window
    {
        public DisplayRecipeWindow(Recipe recipe)
        {
            InitializeComponent();
            RecipeNameTextBlock.Text = recipe.Name;
            IngredientListBox.ItemsSource = recipe.Ingredients;
            TotalCaloriesTextBlock.Text = recipe.TotalCalories.ToString(); // Set the Text property
            StepListBox.ItemsSource = recipe.Steps;
        }
    }
}
