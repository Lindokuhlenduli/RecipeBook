﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeBookWPF.Models
{
    public class Ingredient
    {
        public string Name { get; set; }
        public float Quantity { get; set; }
        public string Unit { get; set; } // Non-nullable property causing CS8618 warning
        public float Calories { get; set; }
        public string FoodGroup { get; set; }
        //public string Description { get; set; }

        public Ingredient(string name, float quantity, string unit, float calories, string foodGroup)
        {
            Name = name;
            Quantity = quantity;
            Unit = unit; // Initialize the Unit property in the constructor
            Calories = calories;
            FoodGroup = foodGroup;
            
        }
    }

}



