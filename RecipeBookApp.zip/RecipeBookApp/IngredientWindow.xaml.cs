﻿using System.Windows;
using RecipeBookApp;
using RecipeBookWPF.Models;

namespace RecipeBookWPF
{
    public partial class IngredientWindow : Window
    {
        public Ingredient Ingredient { get; private set; }

        public IngredientWindow()
        {
            InitializeComponent();
        }
       
        private void AddIngredientButton_Click(object sender, RoutedEventArgs e)
        {
            var name = IngredientNameTextBox.Text; // Get the text from the TextBox
            if (float.TryParse(QuantityTextBox.Text, out float quantity) &&
                float.TryParse(CaloriesTextBox.Text, out float calories))
            {
                var unit = UnitTextBox.Text; // Get the text from the TextBox
                var foodGroup = FoodGroupTextBox.Text; // Get the text from the TextBox
                Ingredient = new Ingredient(name, quantity, unit, calories, foodGroup);
                DialogResult = true;
            }
            else
            {
                MessageBox.Show("Please enter valid numbers for quantity and calories.");
            }
        }
    }
}
