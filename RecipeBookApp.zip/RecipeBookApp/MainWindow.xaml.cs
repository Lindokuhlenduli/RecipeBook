﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Linq;
using RecipeBookWPF.Models;
using RecipeBookApp;

namespace RecipeBookWPF
{
    public partial class MainWindow : Window
    {
        private readonly List<Recipe> _recipes = new List<Recipe>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void EnterRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            var newRecipe = new Recipe();
            var recipeWindow = new RecipeWindow(newRecipe);
            if (recipeWindow.ShowDialog() == true)
            {
                _recipes.Add(newRecipe);
                UpdateRecipeList();
            }
        }

        private void DisplayRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            if (RecipeListBox.SelectedItem is Recipe selectedRecipe)
            {
                var displayWindow = new DisplayRecipeWindow(selectedRecipe);
                displayWindow.ShowDialog();
            }
            else
            {
                MessageBox.Show("Please select a recipe to display.");
            }
        }

        public void UpdateRecipeList()
        {
            RecipeListBox.ItemsSource = null;
            RecipeListBox.ItemsSource = _recipes.OrderBy(r => r.Name).ToList();
        }

        private void ClearDataButton_Click(object sender, RoutedEventArgs e)
        {
            _recipes.Clear();
            UpdateRecipeList();
            MessageBox.Show("Data cleared successfully.");
        }

    }
}