﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeBookWPF.Models
{
    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; } = new List<Ingredient>();
        public List<string> Steps { get; set; } = new List<string>();

        public float TotalCalories
        {
            get { return Ingredients.Sum(i => i.Calories); }
        }

        public object Instructions { get; internal set; }

        public void AddIngredient(Ingredient ingredient)
        {
            Ingredients.Add(ingredient);
        }

        public void AddStep(string step)
        {
            Steps.Add(step);
        }
    }

    public class ingredient
    {
        public string Name { get; }
        public float Quantity { get; set; }
        public string Unit { get; }
        public float Calories { get; }
        public string FoodGroup { get; }

        public ingredient(string name, float quantity, string unit, float calories, string foodGroup)
        {
            Name = name;
            Quantity = quantity;
            Unit = unit;
            Calories = calories;
            FoodGroup = foodGroup;
        }
    }
}

